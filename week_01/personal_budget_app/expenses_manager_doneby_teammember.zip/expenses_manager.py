from tkinter import *
from tkinter import messagebox
from datetime import datetime
import sqlite3
import pandas as pd
import csv


class Database:
    def __init__(self, db):
        self.conn = sqlite3.connect(db)
        self.cur = self.conn.cursor()
        self.cur.execute(
            "CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, title TEXT, summ REAL, date TEXT, payment_type INTEGER)")
        self.conn.commit()

    def fetch(self):
        self.cur.execute("SELECT * FROM payments")
        rows = self.cur.fetchall()
        return rows

    def insert(self, title, summ, date, payment_type):
        self.cur.execute("INSERT INTO payments VALUES (NULL, ?, ?, ?, ?)",
                         (title, summ, date, payment_type))
        self.conn.commit()

    def remove(self, id):
        self.cur.execute("DELETE FROM payments WHERE id=?", (id,))
        self.conn.commit()

    def update(self, id, title, summ, date, payment_type):
        self.cur.execute("UPDATE payments SET title = ?, summ = ?, date = ?, payment_type = ? WHERE id = ?",
                         (title, summ, date, payment_type, id))

        self.conn.commit()

    def __del__(self):
        self.conn.close()


PAYMENT_TYPE = [
    "expense",
    "income"
]

FONT_SIZE = 12

db = Database("payments.db")

sql = pd.read_sql_query("SELECT * FROM payments", db.conn)
df_payments = pd.DataFrame(sql)
df_payments.set_index('id', inplace=True)

print(df_payments)


def populate_list():
    payments_list.delete(0, END)
    data = db.fetch()
    for (i, row) in zip(range(len(data)), data):
        line_color = 'red'
        if row[4] == 1:
            line_color = 'green'
        payments_list.insert(END, row)
        payments_list.itemconfig(i, foreground=line_color)


def add_item():
    if not title_text.get() or not summ_text.get():
        messagebox.showerror('Required Fields', 'Please include all fields')
        return
    selection = payment_type.get()
    payment = 0
    if selection == "income":
        payment = 1
    db.insert(title_text.get(), summ_text.get(), datetime.now(), payment)
    payments_list.delete(0, END)
    payments_list.insert(
        END, (title_text.get(), summ_text.get(), datetime.now(), payment))
    clear_text()
    populate_list()


def select_item(event):
    global selected_item
    index = payments_list.curselection()[0]
    selected_item = payments_list.get(index)

    title_entry.delete(0, END)
    title_entry.insert(END, selected_item[1])

    summ_entry.delete(0, END)
    summ_entry.insert(END, selected_item[2])

    payment_type.set(PAYMENT_TYPE[int(selected_item[4])])


def remove_item():
    db.remove(selected_item[0])
    clear_text()
    populate_list()


def update_item():
    selection = payment_type.get()
    payment = 0
    if selection == "income":
        payment = 1
    db.update(selected_item[0], title_text.get(),
              summ_text.get(), datetime.now(), payment)
    populate_list()


def clear_text():
    title_entry.delete(0, END)
    summ_entry.delete(0, END)
    payment_type.set(PAYMENT_TYPE[0])


def calculate_balance():
    total = 0
    for row in db.fetch():
        if row[4] == 0:
            total -= row[2]
        else:
            total += row[2]
    balance_output_label.config(text=f"balance = {total}")


def prepare_report(data):
    with open('payments.csv', 'a') as f:
        w = csv.writer(f, dialect='excel')
        w.writerows(data)


app = Tk()

title_text = StringVar()
title_label = Label(app,
                    text="payment name:",
                    font=('bold', FONT_SIZE),
                    padx=10,
                    pady=20)
title_label.grid(row=0, column=0, sticky=W)
title_entry = Entry(app, textvariable=title_text)
title_entry.grid(row=0, column=1)

summ_text = StringVar()
summ_label = Label(app,
                   text="summ:",
                   font=('bold', FONT_SIZE),
                   padx=10,
                   pady=20)
summ_label.grid(row=0, column=2, sticky=W)
summ_entry = Entry(app, textvariable=summ_text)
summ_entry.grid(row=0, column=3)

payment_type = StringVar()
payment_type.set(PAYMENT_TYPE[0])  # default value
payment_label = Label(app,
                      text="type:",
                      font=('bold', FONT_SIZE),
                      padx=10,
                      pady=20)
payment_label.grid(row=0, column=4, sticky=W)
payment_option = OptionMenu(
    app, payment_type, *PAYMENT_TYPE)
payment_option.grid(row=0, column=5)

# Payments list
payments_list = Listbox(app, height=8, width=50, border=0)
payments_list.grid(row=2, column=0, columnspan=3, rowspan=6, pady=20, padx=20)

scrollbar = Scrollbar(app)
scrollbar.grid(row=2, column=3, pady=20, padx=20)
payments_list.configure(yscrollcommand=scrollbar.set)
scrollbar.configure(command=payments_list.yview)

# Bind select
payments_list.bind('<<ListboxSelect>>', select_item)

# Buttons
add_btn = Button(app, text="Add payment", width=15, command=add_item)
add_btn.grid(row=1, column=0)

remove_btn = Button(app, text="Remove payment", width=15, command=remove_item)
remove_btn.grid(row=1, column=1)

update_btn = Button(app, text="Update payment", width=15, command=update_item)
update_btn.grid(row=1, column=2)

clear_btn = Button(app, text="Clear input", width=15, command=clear_text)
clear_btn.grid(row=1, column=3)

account_state_btn = Button(
    app, text="Calculate balance", width=20, command=calculate_balance)
account_state_btn.grid(row=8, column=0)

generate_report_btn = Button(
    app, text="Generate report", width=20, command=lambda: prepare_report(db.fetch()))
generate_report_btn.grid(row=9, column=0)

# Calculate balance output
balance_output_label = Label(app, text='', font=('bold', FONT_SIZE))
balance_output_label.grid(row=8, column=1)


app.title("Expenses Manager")
app.geometry('700x350')

populate_list()

# Start program
app.mainloop()
